function [Q,param]=adapttrap(f,param)

param.nmin=max(param.nmin,2*param.Mcone); %minimum number of trapezoids
xpts=linspace(0,1,param.nmin+1);
fpts=f(xpts);
sumf=(fpts(1)+fpts(param.nmin+1))/2+sum(fpts(2:param.nmin));
ntrap=param.nmin;
while ntrap<param.nmax
    absfirstdiff=sum(abs(diff(fpts)));
    errest=param.Mcone*absfirstdiff/(8*ntrap*(ntrap-param.Mcone));
    if errest <= param.tol || ntrap > param.nmax/2
        Q=sumf/ntrap;
        break
    else
        ntrapold=ntrap;
        ntrap=2*ntrap;
        xnew=linspace(xpts(2)/2,(xpts(end-1)+1)/2,ntrapold);
        fnew=f(xnew);
        sumf=sumf+sum(fnew);
        xpts=[reshape([xpts(1:ntrapold);xnew],1,ntrap) xpts(ntrapold+1)];
        fpts=[reshape([fpts(1:ntrapold);fnew],1,ntrap) fpts(ntrapold+1)];
    end
end
param.Q=Q;
param.ntrap=ntrap;
param.errest=errest;
        