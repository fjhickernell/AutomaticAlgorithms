%try out adapttrap
param.tol=1e-3;
[Q,param]=adapttrap(sin,param);
Q
1-cos(1)