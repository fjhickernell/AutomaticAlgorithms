% Figures for DePaul Talk
close all, clear all
set(0,'defaultaxesfontsize',24,'defaulttextfontsize',24)
format compact
pink=[1,0.75,0.75];
ltgrn=[0.75,1,0.75];
ltblue=[0.75,0.75,1];

%% Trapezoid
x=[0.3 0.7 0.7 0.3];
y=[0.3 0.2 0.8 0.6];
figure; 
fill(x,y,ltblue,'edgecolor','blue','linewidth',2);
axis([0 1 0 1])
axis equal
axis off
[xarr,yarr]=dsxy2figxy(gca,0.25*[1 1],[0.3,0.6]);
annotation('doublearrow',xarr,yarr)
text(0.18,0.45,'$y_1$','Interpreter','Latex')
[xarr,yarr]=dsxy2figxy(gca,0.75*[1 1],[0.2 0.8]);
annotation('doublearrow',xarr,yarr)
text(0.77,0.45,'$y_2$','Interpreter','Latex')
[xarr,yarr]=dsxy2figxy(gca,[0.3 0.7],0.15*[1 1]);
annotation('doublearrow',xarr,yarr)
text(0.5,0.1,'$w$','Interpreter','Latex')
print -depsc trapezoid.eps

%% Area under f
f=@(x) exp(-5*x);
area=(1-exp(-5))/5
nplot=300;
xplot=(0:nplot)/nplot;
fplot=f(xplot);
x=[xplot 1 0 0];
y=[fplot 0 0 f(0)];
figure; 
fill(x,y,ltblue,'edgecolor','blue','linewidth',0.5);
hold on
plot(xplot,fplot,'-b',[0 1],area*[1,1],'r--','linewidth',3)
text(0.55,area+0.06,['average=' num2str(area,4)],'Color','red')
axis([0 1 0 1])
print -depsc AreaUnderfeasy.eps

%% Area under f
f=@(x) exp(-5*x.^2);
integerf=sqrt(pi/5)*erf(sqrt(5))/2
integquad=quad(f,0,1,1e-14)
fplot=f(xplot);
x=[xplot 1 0 0];
y=[fplot 0 0 f(0)];
figure; 
fill(x,y,ltblue,'edgecolor','blue','linewidth',0.5);
hold on
plot(xplot,fplot,'-b','linewidth',3)
axis([0 1 0 1])
print -depsc AreaUnderfhard.eps

%% Trapezoidal rule
nvec=[1 2 4 50];
nn=length(nvec);
traprule=zeros(nn,1);
for i=1:nn
    n=nvec(i);
    xtrap=(0:n)/n;
    ftrap=f(xtrap);
    traprule(i)=((ftrap(1)+ftrap(n+1))/2+sum(ftrap(2:n)))/n;
    figure;
    xfill=[0 xtrap 1 0];
    yfill=[0 ftrap 0 0];
    fill(xfill,yfill,pink,'edgecolor','red','linewidth',0.5);
    hold on
    xbox=[xtrap(1:n); xtrap(1:n); xtrap(2:n+1); xtrap(2:n+1)]; 
    ybox=[zeros(1,n); ftrap(1:n); ftrap(2:n+1); zeros(1,n)];
    xbox=xbox(:);
    ybox=ybox(:);
    plot(xbox,ybox,'r-')
    plot(xplot,fplot,'b-','linewidth',3)
    eval(['print -depsc traprule-' int2str(i) '.eps'])
end
traprule
errorn=integerf-traprule(nn)
trapnov2=((ftrap(1)+ftrap(n+1))/2+sum(ftrap(3:2:n-1)))*(2/n);
errest=(traprule(nn)-trapnov2)/3

%% Trapezoidal rule fooling functions
traprule=zeros(nn,1);
integf=traprule;
for i=1:nn
    n=nvec(i);
    if n==2*floor(n/2) %n is even
    xtrap=(0:n)/n;
    a=2*n;
    piece=@(x,c) 1./(1 + a^2*(x-c).^2);
    integpiece=@(c)(atan(a*(1 - c)) + atan(a*c))/a;
    %piece=@(x,c) 1./(exp(a*(x - c)) + exp(-a*(x - c)));
    %integpiece=@(c) (-atan(exp(a*(-1 + c))) + atan(exp(a*c)))/a;
    ncent=20;
    centers=(0:ncent-1)/(ncent-1);
    nconst=3;
    A=zeros(nconst,ncent); %matrix containing constraints
    b=[1; 0.9; zeros(nconst-2,1)];
    for j=1:ncent
        %constraint to make integral to be one
        A(1,j)=integpiece(centers(j));
        %constraint to make the quadature something else
        A(2,j)=(1/(2*n))*(piece(xtrap(1),centers(j))...
            +2*sum(piece(xtrap(2:n),centers(j)))...
            +piece(xtrap(n+1),centers(j)));
        %constraint to make the n and n/2 quadratures match
        A(3,j)=-(1/2)*piece(xtrap(1),centers(j))...
            +sum(piece(xtrap(2:2:n),centers(j)))...
            -sum(piece(xtrap(3:2:n-1),centers(j)))...
            -(1/2)*piece(xtrap(n+1),centers(j));
    end
    condA=cond(A)
    optcoef=A\b;
    fplot=zeros(size(xplot));
    ftrap=zeros(size(xtrap));
    for j=1:ncent
        fplot=fplot+optcoef(j)*piece(xplot,centers(j));
        ftrap=ftrap+optcoef(j)*piece(xtrap,centers(j));
        integf(i)=integf(i)+optcoef(j)*integpiece(centers(j));
    end
    ymax=max(abs(fplot))
    fplot=fplot/ymax;
    ftrap=ftrap/ymax;
    integf(i)=integf(i)/ymax;
    traprule(i)=((ftrap(1)+ftrap(n+1))/2+sum(ftrap(2:n)))/n;
    figure;
    xfill=[0 xtrap 1 0];
    yfill=[0 ftrap 0 0];
    fill(xfill,yfill,pink,'edgecolor','red','linewidth',0.5);
    hold on
    xbox=[xtrap(1:n); xtrap(1:n); xtrap(2:n+1); xtrap(2:n+1)]; 
    ybox=[zeros(1,n); ftrap(1:n); ftrap(2:n+1); zeros(1,n)];
    xbox=xbox(:);
    ybox=ybox(:);
    plot(xbox,ybox,'r-','linewidth',2)
    xfill=[0 xtrap(1:2:n+1) 1 0];
    yfill=[0 ftrap(1:2:n+1) 0 0];
%     fill(xfill,yfill,ltgrn,'edgecolor','green','linewidth',0.5);
    xbox=[xtrap(1:2:n-1); xtrap(1:2:n-1); xtrap(3:2:n+1); xtrap(3:2:n+1)]; 
    ybox=[zeros(1,n/2); ftrap(1:2:n-1); ftrap(3:2:n+1); zeros(1,n/2)];
    xbox=xbox(:);
    ybox=ybox(:);
    plot(xbox,ybox,'g-','linewidth',2)
    plot(xplot,fplot,'b-','linewidth',3)
    axis([0 1 min(fplot) 1])
    eval(['print -depsc fooltraprule-' int2str(i) '.eps'])
    end
end
integf
traprule

