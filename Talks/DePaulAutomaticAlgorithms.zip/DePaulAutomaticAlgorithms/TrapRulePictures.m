%Average plots
close all, clear all
set(0,'defaultaxesfontsize',24,'defaulttextfontsize',24)
mbig=13;
nbig=2^mbig;

pink=[1,0.75,0.75];
ltgrn=[0.75,1,0.75];

n=5;
nplot=200;

x=(0:n)/n;
xplot=(0:nplot)/nplot;

f=@(x)1+x.*sin(2*pi*x); avgf=1-1/(2*pi);

fx=f(x); trap=((fx(1)+fx(n+1))/2+sum(fx(2:n)))/n;
fplot=f(xplot);

figure; 
fill([x(1:n); x(2:n+1); x(2:n+1); x(1:n)],[fx(1:n); fx(2:n+1); zeros(2,n)],...
    pink,'edgecolor','red','linewidth',1);
hold on
plot(x,fx,'r.',x,fx,'r-',xplot,fplot,'b-',[0 1],trap*[1 1],'r--', [0 1],avgf*[1 1],'b--', ...
    'linewidth',3,'markersize',30); 
axis([0 1 0 1.5])
text(0.6,trap+0.1,['average=' num2str(trap,2)],'Color','red')
text(0.6,avgf-0.1,['average=' num2str(avgf,2)],'Color','blue')
xlabel('{\it x}'); ylabel('{\it f(x)}')
print -depsc Avgfxfi.eps

%%
c=10; z=sqrt(2)/2;
fpeak=@(x) (2*c*exp(-(c*(x-z)).^2))./(sqrt(pi)*(erf(c*z) + erf(c*(1-z))));
fpeakplot=fpeak(xplot);

figure;
plot(xplot,fpeakplot,'b-','linewidth',5);
set(gca,'Visible','off')
%axis([0 1 0 1.5])
%xlabel('{\it x}'); ylabel('{\it f(x)}')
print -depsc GaussianPeak.eps

break